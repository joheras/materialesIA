import os
import cv2

class CargaYDescribe(object):

    def __init__(self, path,descriptor):
        self.descriptor = descriptor
        self.path = path

    def cargaYdescribe(self):
        data = []
        target = []
        for (dir,_,images) in os.walk(self.path):
            for image in images:
                data += [self.descriptor.describe(cv2.imread(dir + "/" + image))]
                target += dir[dir.rfind("/")+1:]
        return (data,target)




