import cv2

class Descriptor(object):

    def __init__(self):
        pass

    def describe(self,imagePath):
        pass

class RawImage(Descriptor):

    def describe(self,image):
        if len(image.shape) == 3:
            image = cv2.cvtColor(image,cv2.COLOR_BGR2GRAY)
        return image.flatten()

class Projection(Descriptor):

    def describe(self, image):
        if len(image.shape) == 3:
            image = cv2.cvtColor(image, cv2.COLOR_BGR2GRAY)
        data = []
        for i in range(0,image.shape[0]):
            data += [image[i,:].sum()]
        for i in range(0, image.shape[1]):
            data += [image[:,i].sum()]
        return data